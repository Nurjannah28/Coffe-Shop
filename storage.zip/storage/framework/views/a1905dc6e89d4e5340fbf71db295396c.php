<div class="copyright_section">
    <div class="container">
        <p class="copyright_text">2020 All Rights Reserved. Design by <a href="https://html.design">Free html
                Templates</a></p>
    </div>
</div>
<?php /**PATH C:\Web Template\laravel10\client4-app\resources\views/components/copyright.blade.php ENDPATH**/ ?>