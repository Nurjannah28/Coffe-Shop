<div class="gallery_section layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h1 class="gallery_taital">Our Gallery</h1>
                <p class="gallery_text">Lorem Ipsum is simply dummy text of printing typesetting ststry lorem Ipsum
                    the industry'ndard dummy text ever since of the 1500s, when an unknown printer took a galley of
                    type and scra make a type specimen book. It has</p>
            </div>
        </div>
        <div class="">
            <div class="gallery_section_2">
                <div class="row">
                    <div class="col-md-4">
                        <div class="container_main">
                            <img src="<?php echo e(asset('assets/images/img-1.png')); ?>" alt="Avatar" class="image">
                            <div class="overlay">
                                <div class="text"><a href="#"><i class="fa fa-search"
                                            aria-hidden="true"></i></a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="container_main">
                            <img src="<?php echo e(asset('assets/images/img-2.png')); ?>" alt="Avatar" class="image">
                            <div class="overlay">
                                <div class="text"><a href="#"><i class="fa fa-search"
                                            aria-hidden="true"></i></a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="container_main">
                            <img src="<?php echo e(asset('assets/images/img-3.png')); ?>" alt="Avatar" class="image">
                            <div class="overlay">
                                <div class="text"><a href="#"><i class="fa fa-search"
                                            aria-hidden="true"></i></a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="gallery_section_2">
                <div class="row">
                    <div class="col-md-4">
                        <div class="container_main">
                            <img src="<?php echo e(asset('assets/images/img-4.png')); ?>" alt="Avatar" class="image">
                            <div class="overlay">
                                <div class="text"><a href="#"><i class="fa fa-search"
                                            aria-hidden="true"></i></a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="container_main">
                            <img src="<?php echo e(asset('assets/images/img-5.png')); ?>" alt="Avatar" class="image">
                            <div class="overlay">
                                <div class="overlay">
                                    <div class="text"><a href="#"><i class="fa fa-search"
                                                aria-hidden="true"></i></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="container_main">
                            <img src="<?php echo e(asset('assets/images/img-6.png')); ?>" alt="Avatar" class="image">
                            <div class="overlay">
                                <div class="overlay">
                                    <div class="text"><a href="#"><i class="fa fa-search"
                                                aria-hidden="true"></i></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="gallery_section_2">
                <div class="row">
                    <div class="col-md-4">
                        <div class="container_main">
                            <img src="<?php echo e(asset('assets/images/img-7.png')); ?>" alt="Avatar" class="image">
                            <div class="overlay">
                                <div class="text"><a href="#"><i class="fa fa-search"
                                            aria-hidden="true"></i></a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="container_main">
                            <img src="<?php echo e(asset('assets/images/img-8.png')); ?>" alt="Avatar" class="image">
                            <div class="overlay">
                                <div class="text"><a href="#"><i class="fa fa-search"
                                            aria-hidden="true"></i></a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="container_main">
                            <img src="<?php echo e(asset('assets/images/img-9.png')); ?>" alt="Avatar" class="image">
                            <div class="overlay">
                                <div class="text"><a href="#"><i class="fa fa-search"
                                            aria-hidden="true"></i></a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="seemore_bt"><a href="#">See More</a></div>
    </div>
</div>
<?php /**PATH C:\Web Template\laravel10\client4-app\resources\views/components/gallery.blade.php ENDPATH**/ ?>