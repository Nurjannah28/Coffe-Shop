<div class="about_section layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="about_taital_main">
                    <div class="about_taital">About Us</div>
                    <p class="about_text">Full cleaning and housekeeping services for companies and households.</p>
                    <p class="about_text">Lorem Ipsum is simply dummy text of the printing and typesetting
                        industry. Lorem Ipsum has been the industry's standard dummy text.Lorem Ipsum is simply</p>
                    <div class="read_bt"><a href="#">Read More</a></div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="about_img"><img src="<?php echo e(asset('assets/images/about-img.png')); ?>"></div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Web Template\laravel10\client4-app\resources\views/components/about.blade.php ENDPATH**/ ?>