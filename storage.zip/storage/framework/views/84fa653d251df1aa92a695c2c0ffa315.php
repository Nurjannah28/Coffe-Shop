<div class="footer_section layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-sm-6">
                <h3 class="useful_text">About</h3>
                <p class="footer_text">consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                    dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation u</p>
            </div>
            <div class="col-lg-3 col-sm-6">
                <h3 class="useful_text">Menu</h3>
                <div class="footer_menu">
                    <ul>
                        <li><a href="/">Home</a></li>
                        <li><a href="/about">About Us</a></li>
                        <li><a href="/gallery">Gallery</a></li>
                        <li><a href="/services">Services</a></li>
                        <li><a href="/contact">Contact Us</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <h1 class="useful_text">Useful Link</h1>
                <p class="dummy_text">Adipiscing Elit, sed do Eiusmod Tempor incididunt </p>
            </div>
            <div class="col-lg-3 col-sm-6">
                <h1 class="useful_text">Contact Us</h1>
                <div class="location_text">
                    <ul>
                        <li>
                            <a href="#">
                                <i class="fa fa-map-marker" aria-hidden="true"></i><span
                                    class="padding_left_10">Address : Loram Ipusm</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa fa-phone" aria-hidden="true"></i><span class="padding_left_10">Call
                                    : +01 1234567890</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa fa-envelope" aria-hidden="true"></i><span
                                    class="padding_left_10">Email : demo@gmail.com</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Web Template\laravel10\client4-app\resources\views/components/footer.blade.php ENDPATH**/ ?>