<div class="contact_section layout_padding">
    <div class="container">
        <h1 class="contact_text">Contact Us</h1>
    </div>
</div>
<div class="contact_section_2 layout_padding">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 padding_0">
                <div class="mail_section">
                    <div class="email_text">
                        <div class="form-group">
                            <input type="text" class="email-bt" placeholder="Name" name="Email">
                        </div>
                        <div class="form-group">
                            <input type="text" class="email-bt" placeholder="Email" name="Email">
                        </div>
                        <div class="form-group">
                            <input type="text" class="email-bt" placeholder="Phone Numbar" name="Email">
                        </div>
                        <div class="form-group">
                            <textarea class="massage-bt" placeholder="Massage" rows="5" id="comment" name="Massage"></textarea>
                        </div>
                        <div class="send_btn">
                            <div type="text" class="main_bt"><a href="#">SEND</a></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 padding_0">
                <div class="map-responsive">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d65239062.2274504!2d20.663448899999988!3d3.6157391000000234!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x303131799362061b%3A0x56ca1aeb5f77fa7a!2sInstitut%20Teknologi%20Sawit%20Indonesia%20-%20ITSI%20Medan!5e0!3m2!1sid!2sid!4v1742485492244!5m2!1sid!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"
                        width="600" height="508" frameborder="0" style="border:0; width: 100%;"
                        allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</div>
