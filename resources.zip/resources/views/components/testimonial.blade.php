<div class="client_section layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h1 class="client_taital">Testimonial</h1>
                <p class="client_text">Eeven slightly believable. If you are going to use a passage of Lorem Ipsum,
                    you need to</p>
            </div>
        </div>
    </div>
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <div class="client_section_2">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="testimonial_section_2">
                                    <h4 class="client_name_text">Monila <span class="quick_icon"><img
                                                src="{{ asset('assets/images/quick-icon.png') }}"></span></h4>
                                    <p class="customer_text">many variations of passages of Lorem Ipsum available,
                                        but the majority have suffered alteration in some form, by injected humour,
                                        or randomised words which don't look even slightly believable. If you are
                                        going to use a passage of Lorem Ipsum, you need to be sure there isn't
                                        anything embarrassing hidden in the middle of text. All themany variations
                                        of passages of Lorem Ipsum available, but the majority have suffered
                                        alteration in some embarrassing hidden in the middle of text. All the</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <div class="client_section_2">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="testimonial_section_2">
                                    <h4 class="client_name_text">Monila <span class="quick_icon"><img
                                                src="{{ asset('assets/images/quick-icon.png') }}"></span></h4>
                                    <p class="customer_text">many variations of passages of Lorem Ipsum available,
                                        but the majority have suffered alteration in some form, by injected humour,
                                        or randomised words which don't look even slightly believable. If you are
                                        going to use a passage of Lorem Ipsum, you need to be sure there isn't
                                        anything embarrassing hidden in the middle of text. All themany variations
                                        of passages of Lorem Ipsum available, but the majority have suffered
                                        alteration in some embarrassing hidden in the middle of text. All the</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <div class="client_section_2">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="testimonial_section_2">
                                    <h4 class="client_name_text">Monila <span class="quick_icon"><img
                                                src="{{ asset('assets/images/quick-icon.png') }}"></span></h4>
                                    <p class="customer_text">many variations of passages of Lorem Ipsum available,
                                        but the majority have suffered alteration in some form, by injected humour,
                                        or randomised words which don't look even slightly believable. If you are
                                        going to use a passage of Lorem Ipsum, you need to be sure there isn't
                                        anything embarrassing hidden in the middle of text. All themany variations
                                        of passages of Lorem Ipsum available, but the majority have suffered
                                        alteration in some embarrassing hidden in the middle of text. All the</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
