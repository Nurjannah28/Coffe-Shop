<div class="services_section layout_padding">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h1 class="services_taital">Services</h1>
                <p class="services_text">Typesetting industry lorem Ipsum is simply dummy text of the </p>
            </div>
        </div>
        <div class="services_section_2">
            <div class="row">
                <div class="col-lg-4 col-sm-12 col-md-4">
                    <div class="box_main active">
                        <div class="house_icon">
                            <img src="{{ asset('assets/images/icon1.png') }}" class="image_1">
                            <img src="{{ asset('assets/images/icon1.png') }}" class="image_2">
                        </div>
                        <h3 class="decorate_text">Original Coffee</h3>
                        <p class="tation_text">Exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea
                        </p>
                        <div class="readmore_bt"><a href="#">Read More</a></div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-12 col-md-4">
                    <div class="box_main">
                        <div class="house_icon">
                            <img src="{{ asset('assets/images/icon2.png') }}" class="image_1">
                            <img src="{{ asset('assets/images/icon2.png') }}" class="image_2">
                        </div>
                        <h3 class="decorate_text">20 Coffee Flavors</h3>
                        <p class="tation_text">Exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea
                        </p>
                        <div class="readmore_bt"><a href="#">Read More</a></div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-12 col-md-4">
                    <div class="box_main">
                        <div class="house_icon">
                            <img src="{{ asset('assets/images/icon3.png') }}" class="image_1">
                            <img src="{{ asset('assets/images/icon3.png') }}" class="image_2">
                        </div>
                        <h3 class="decorate_text">Pleasant Abient</h3>
                        <p class="tation_text">Exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea
                        </p>
                        <div class="readmore_bt"><a href="#">Read More</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
