@extends('layouts.app')
@section('content')
    @include('components.services')
@endsection
