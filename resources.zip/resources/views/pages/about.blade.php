@extends('layouts.app')
@section('content')
    @include('components.about')
@endsection
