@extends('layouts.app')
@section('content')
    @include('components.gallery')
@endsection
